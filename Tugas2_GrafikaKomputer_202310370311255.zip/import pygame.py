import pygame
import sys

pygame.init()
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Simple Drawing App")
clock = pygame.time.Clock()

current_color = (255, 0, 0)
draw_mode = "dot"

color_buttons = {
    "Red": (255, 0, 0),
    "Green": (0, 255, 0),
    "Blue": (0, 0, 255),
    "Black": (0, 0, 0),
}

modes = ["dot", "line", "rect", "circle"]
start_pos = None

# 🆕 Buat canvas untuk menyimpan hasil gambar
canvas = pygame.Surface(screen.get_size())
canvas.fill((255, 255, 255))

def draw_buttons():
    y = 10
    for name, color in color_buttons.items():
        pygame.draw.rect(screen, color, (10, y, 60, 30))
        y += 40

    y = 10
    for mode in modes:
        pygame.draw.rect(screen, (200, 200, 200), (700, y, 80, 30))
        font = pygame.font.SysFont(None, 24)
        text = font.render(mode, True, (0, 0, 0))
        screen.blit(text, (705, y + 5))
        y += 40

def handle_color_selection(pos):
    y = 10
    for name, color in color_buttons.items():
        if pygame.Rect(10, y, 60, 30).collidepoint(pos):
            return color
        y += 40
    return None

def handle_mode_selection(pos):
    y = 10
    for mode in modes:
        if pygame.Rect(700, y, 80, 30).collidepoint(pos):
            return mode
        y += 40
    return None

running = True
while running:
    screen.fill((255, 255, 255))
    screen.blit(canvas, (0, 0))  # 🆕 Gambar ulang canvas agar coretan tetap terlihat
    draw_buttons()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.MOUSEBUTTONDOWN:
            color = handle_color_selection(event.pos)
            if color:
                current_color = color

            mode = handle_mode_selection(event.pos)
            if mode:
                draw_mode = mode
            else:
                start_pos = event.pos
                if draw_mode == "dot":
                    pygame.draw.circle(canvas, current_color, event.pos, 3)

        elif event.type == pygame.MOUSEBUTTONUP:
            if start_pos:
                end_pos = event.pos
                if draw_mode == "line":
                    pygame.draw.line(canvas, current_color, start_pos, end_pos, 2)
                elif draw_mode == "rect":
                    rect = pygame.Rect(*start_pos, end_pos[0]-start_pos[0], end_pos[1]-start_pos[1])
                    pygame.draw.rect(canvas, current_color, rect, 2)
                elif draw_mode == "circle":
                    radius = int(((end_pos[0] - start_pos[0]) ** 2 + (end_pos[1] - start_pos[1]) ** 2) ** 0.5)
                    pygame.draw.circle(canvas, current_color, start_pos, radius, 2)
                start_pos = None

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()