#!/bin/bash

# Membuat README.md untuk aplikasi Simple Drawing App

cat << EOF > README.md
# 🖌️ Simple Drawing App with Python (Pygame)

Aplikasi sederhana untuk menggambar bentuk-bentuk dasar seperti titik, garis, persegi, dan lingkaran menggunakan *mouse. Dibuat dengan **Python* dan *Pygame*, cocok sebagai latihan interaktif atau demo yang dapat dijalankan di desktop maupun di web (itch.io).

---

## 🎯 Fitur Utama
- Mode menggambar:
  - 🟢 Titik (Dot)
  - 📏 Garis (Line)
  - 🟥 Persegi (Rectangle)
  - 🟠 Lingkaran (Circle)
- Pilihan warna:
  - 🔴 Merah
  - 🔵 Biru
  - 🟢 Hijau
  - ⚫ Hitam
- Interaksi dengan mouse:
  - Klik untuk menggambar
  - Drag untuk bentuk garis, persegi, dan lingkaran
- *Tidak menyimpan ke file*
- Semua coretan *disimpan di layar* (tidak hilang setelah frame berikutnya)

---

## 🚀 Cara Menjalankan

### 1. Clone repositori / simpan file
Simpan kode Python sebagai \drawing_app.py\.

### 2. Instalasi Pygame
Pastikan kamu memiliki Python 3.7 atau lebih baru, lalu jalankan:
\\\`bash
pip install pygame
\\\`

### 3. Jalankan Aplikasi
\\\`bash
python drawing_app.py
\\\`

---

## 🕹️ Kontrol

| Aksi                        | Penjelasan                                  |
|----------------------------|---------------------------------------------|
| Klik tombol warna          | Mengubah warna coretan                      |
| Klik tombol mode (kanan)   | Mengubah bentuk yang akan digambar          |
| Klik/drag di area tengah   | Menggambar bentuk sesuai mode yang dipilih  |

---

## 🌐 Untuk Web / itch.io
Aplikasi ini dapat diubah menjadi versi web menggunakan:
- \pygame-wasm\ (WASM build dari Pygame)
- \pyodide\ jika diubah jadi HTML+JS Python interpreter
- *Export sebagai .zip* lalu upload ke itch.io dengan konfigurasi HTML runner

---

## 🛠️ Struktur Kode
- \pygame.Surface()\ digunakan sebagai *canvas permanen* untuk menyimpan gambar
- \screen.blit(canvas, ...)\ menjaga coretan tetap tampil
- Event mouse digunakan untuk menggambar interaktif

---

## 📌 Catatan
Aplikasi ini dikembangkan sebagai bagian dari tugas:
> “Buat aplikasi menggambar titik, garis, persegi, dan lingkaran menggunakan mouse tanpa penyimpanan file.”

EOF